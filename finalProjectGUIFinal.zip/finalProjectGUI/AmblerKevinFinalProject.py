# Import statements
from tkinter import *
from PIL import ImageTk, Image

# Defines initial values
deliveryMethod = 0
itemNum = 0
cartItemNum = 0
subtotal = 0.0
undoCost = 0.0
undoEnabled = False


def close_all():  # Closes all windows, including hidden
    homeWindow.destroy()
    orderWindow.destroy()
    cartWindow.destroy()
    checkoutWindow.destroy()
    root.destroy()


def create_banner(window):  # Function to create banner on each window
    banner = Frame(window, bg="green", padx=10, pady=10)
    banner.grid(column=0, row=0, sticky="N E W")

    Label(banner, image=logoImage).grid(column=1, row=1, padx=10, pady=5, sticky="N E W")  # Left-hand logo
    Label(banner, text="Luigi's Homestyle Pizzeria").grid(column=2, row=1, padx=10, pady=5, sticky="N W")  # Window banner
    Button(banner, image=cartImage, command=cart_move).grid(column=3, row=1, padx=10, pady=5, sticky="N E")  # Button to go direct to cart


def create_bg(window):  # Function to create banner on each window
    backing = Frame(window, padx=10, pady=10)
    backing.grid(column=0, row=1, sticky="W E S")
    return backing


def tax_calc():  # Function to perform tax calculations
    global taxCheckoutOutput, totalCheckoutOutput
    totalTax = subtotal * 0.07
    totalCost = subtotal + totalTax

    taxCheckoutOutput.config(text="$" + str(round(totalTax, 2)))  # Updates display
    totalCheckoutOutput.config(text="$" + str(round(totalCost, 2)))  # Updates display


def remove_last():  # Function to remove the last added item
    global subtotal, subtotalCartOutput, element1, element2, element3
    element1.destroy()
    element2.destroy()
    element3.destroy()

    subtotal -= undoCost  # Refunds the cost
    tax_calc()

    subtotalCartOutput.config(text="$" + str(round(subtotal, 2)))  # Updates display
    subtotalCheckoutOutput.config(text="$" + str(round(subtotal, 2)))  # Updates display

    undoButton.config(state=DISABLED)  # Disables button from being pressed multiple times


def add_item(itemName, price, quantity):  # Function to add an item to user's cart
    global subtotal, subtotalCartOutput, undoCost, undoButton
    undoCost = (price * quantity)
    subtotal += undoCost
    tax_calc()

    item_listing(cartBacking, itemName, round((price * quantity), 2), "remove", quantity)  # Creates item in cartWindow
    subtotalCartOutput.config(text="$"+str(round(subtotal, 2)))  # Updates display
    subtotalCheckoutOutput.config(text="$"+str(round(subtotal, 2)))  # Updates display

    undoButton.config(state=ACTIVE)  # Re-enables button to be pressed again


def item_listing(frame, itemName, price, function, quantity=0):  # Creates the item listing in whichever window is specified
    global itemNum, cartItemNum, undoEnabled, cartBacking, element1, element2, element3, element4, element5, undoButton
    # Determines if listing is being created for orderWindow or cartWindow
    if quantity == 0:  # For orderWindow
        nextRow = itemNum + 2
        itemNum += 1
    else:  # For cartWindow
        nextRow = cartItemNum + 2
        cartItemNum += 1

    if function == "add":  # For orderWindow
        Label(frame, text=itemName).grid(column=1, row=itemNum + 1)

        qtTextbox = Entry(frame)  # Creates the entry box and default value
        qtTextbox.insert(0, "Quantity")
        qtTextbox.grid(column=3, row=itemNum + 1)

        # Creates button to call add_item function
        Button(frame, text="Add", command=lambda: add_item(itemName, price, int(qtTextbox.get()))).grid(column=5,
                                                                                                            row=itemNum + 1)
        Label(frame, text="$" + str(price)).grid(column=6, row=itemNum + 1)

    elif function == "remove":  # For cartWindow
        element1 = Label(frame, text=itemName)
        element1.grid(column=1, row=nextRow)

        element2 = Label(frame, text="Qt: " + str(quantity))  # Displays previously gathered user entry
        element2.grid(column=2, row=nextRow)

        element3 = Label(frame, text="$" + str(price))
        element3.grid(column=3, row=nextRow)

        if not undoEnabled:  # Creates the undo button only when at least one thing has been added to the cart
            undoButton = Button(cartBacking, text="Undo Last", command=lambda: remove_last())
            undoButton.grid(column=1, row=1001)
            undoEnabled = True


def order_move():  # Moves focus to orderWindow
    homeWindow.withdraw()
    cartWindow.withdraw()

    orderWindow.deiconify()
    orderWindow.update()


def cart_move():  # Moves focus to cartWindow
    homeWindow.withdraw()
    orderWindow.withdraw()
    checkoutWindow.withdraw()

    cartWindow.deiconify()
    cartWindow.update()


def checkout_move():  # Moves focus to checkoutWindow
    cartWindow.withdraw()

    checkoutWindow.deiconify()
    checkoutWindow.update()


def home_move():  # Moves focus to homeWindow
    checkoutWindow.withdraw()

    exitMessage.config(text="Order Placed! Hungry for more?")  # Order confirmation message

    homeWindow.deiconify()
    homeWindow.update()


root = Tk()  # Creates and hides the initial Tk() entity
root.withdraw()

# Resizes and opens the images for the banner
image = Image.open("Logo.png")
resize = image.resize((25, 25))
logoImage = ImageTk.PhotoImage(resize)
image = Image.open("ShoppingCart.png")
resize = image.resize((25, 25))
cartImage = ImageTk.PhotoImage(resize)

# Start of section on cartWindow
# Initial construction of cartWindow
cartWindow = Toplevel()
cartWindow.title("Luigi's Homestyle Pizzeria App")
cartWindow.columnconfigure(0, weight=1)
cartWindow.rowconfigure(0, weight=1)

create_banner(cartWindow)
cartBacking = create_bg(cartWindow)
Label(cartBacking, text="Your Cart:").grid(column=1,row=1)

Label(cartBacking, text="Subtotal:").grid(column=2, row=1000)
subtotalCartOutput = Label(cartBacking, text="$0.00")
subtotalCartOutput.grid(column=3, row=1000)

Button(cartBacking, text="Continue Ordering", command=order_move).grid(column=2, row=1001)  # Button moves focus to orderWindow
Button(cartBacking, text="Checkout", command=checkout_move).grid(column=3, row=1001)  # Button moves focus to checkoutWindow

cartWindow.withdraw()


checkoutWindow = Toplevel()
checkoutWindow.title("Luigi's Homestyle Pizzeria App")
checkoutWindow.columnconfigure(0, weight=1)
checkoutWindow.rowconfigure(0, weight=1)

create_banner(checkoutWindow)
checkoutBacking = create_bg(checkoutWindow)
Label(checkoutBacking, text="CHECKOUT").grid(column=1, row=1)

Label(checkoutBacking, text="Name for Order:").grid(column=1, row=2)
nameTextbox = Entry(checkoutBacking)
nameTextbox.insert(0, "Name")
nameTextbox.grid(column=2, row=2)

Label(checkoutBacking, text="Time for Pickup:").grid(column=1, row=3)
timeTextbox = Entry(checkoutBacking)
timeTextbox.insert(0, "Time")
timeTextbox.grid(column=2, row=3)

Label(checkoutBacking, text="Special Requests:").grid(column=1, row=4)
requestTextbox = Entry(checkoutBacking)
requestTextbox.insert(0, "")
requestTextbox.grid(column=2, row=4)

Label(checkoutBacking, text="Payment will be made on arrival.").grid(column=2, row=5)

Label(checkoutBacking, text="Subtotal:").grid(column=5, row=998)
subtotalCheckoutOutput = Label(checkoutBacking, text="$0.00")
subtotalCheckoutOutput.grid(column=6, row=998)

Label(checkoutBacking, text="Tax:").grid(column=5, row=999)
taxCheckoutOutput = Label(checkoutBacking, text="$0.00")
taxCheckoutOutput.grid(column=6, row=999)

Label(checkoutBacking, text="Total:").grid(column=5, row=1000)
totalCheckoutOutput = Label(checkoutBacking, text="$0.00")
totalCheckoutOutput.grid(column=6, row=1000)

Button(checkoutBacking, text="Back to Cart", command=lambda: cart_move()).grid(column=5, row=1001)
Button(checkoutBacking, text="Place Order", command=lambda: home_move()).grid(column=6, row=1001)

checkoutWindow.withdraw()


#def order_move():
orderWindow = Toplevel()
orderWindow.title("Luigi's Homestyle Pizzeria App")
orderWindow.columnconfigure(0, weight=1)
orderWindow.rowconfigure(0, weight=1)

create_banner(orderWindow)
orderBacking = create_bg(orderWindow)
Label(orderBacking, text="What would you like to order?").grid(column=1,row=1)

item_listing(orderBacking, "Meat Pizza", 19.99, "add")
item_listing(orderBacking, "Veg Pizza", 18.99, "add")
item_listing(orderBacking, "Cheese Pizza", 16.99, "add")
item_listing(orderBacking, "Breadsticks", 8.99, "add")
item_listing(orderBacking, "Cheesy Bread", 10.99, "add")

Button(orderBacking, text="Finalize Order", command=cart_move).grid(column=6, sticky="S")

orderWindow.withdraw()


homeWindow = Toplevel()
homeWindow.title("Luigi's Homestyle Pizzeria App")
homeWindow.columnconfigure(0, weight=1)
homeWindow.rowconfigure(0, weight=1)

create_banner(homeWindow)
homeBacking = create_bg(homeWindow)

Label(homeBacking, text="Welcome to Luigi's! Select an option below:").grid(column=2, row=1)
Button(homeBacking, text="Begin Ordering", command=lambda: order_move()).grid(column=2, row=2)

exitMessage = Label(homeBacking, text="")
exitMessage.grid(column=2, row=3)

Button(homeBacking, text="Exit App", command=close_all).grid(column=2, row=4)

homeWindow.protocol("WM_DELETE_WINDOW", close_all)
orderWindow.protocol("WM_DELETE_WINDOW", close_all)
cartWindow.protocol("WM_DELETE_WINDOW", close_all)
checkoutWindow.protocol("WM_DELETE_WINDOW", close_all)

root.mainloop()



